import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { Montserrat_Bold, Poppins_Bold, Poppins_Regular, theme_clr_10, theme_clr_10_transparent_0_max, theme_clr_2, theme_clr_4, theme_clr_dark, theme_clr_light_grey, theme_clr_white } from '../../../style_sheet/styles';
import AppButton from '../Buttons/AppButton';

const AssignedDeliveryCard = ({ data, on_press = null }) => {

    console.log('AssignedDeliveryCard data:', data);

    const date = new Date(data.schedule_date_time);
    const formattedDate = date.toLocaleString();
    console.log(formattedDate);

    return (
        <View style={styles.main_view}>

            <Text style={styles.deliveries}>{data.status}</Text>
            <Text style={[styles.deliveries, { backgroundColor: 'transparent', top: 10, right: 0 }]}>Order #{data.order_number}</Text>


            <View style={{ marginTop: 15, gap: 5, width: '100%' }}>

                <Text style={styles.text_1}>Fuel Type :
                    <Text style={styles.text_2}> {data.fuel_type}</Text></Text>

                <Text style={styles.text_1}>Fuel Quantity :
                    <Text style={styles.text_2}> {data.quantity} Liters</Text></Text>

                <Text style={styles.text_1}>Fuel Price :
                    <Text style={styles.text_2}> {data.price} PKR</Text></Text>

                <Text style={styles.text_1}>Drop Address :
                    <Text style={styles.text_2}> {data.drop_address}</Text></Text>

                <Text style={styles.text_1}>Schedule Date :
                    <Text style={styles.text_2}> {formattedDate}</Text></Text>


                <View style={{ marginVertical: 20 }}>
                    <AppButton
                        on_press={on_press}
                        text={'Start Journey'}
                        fsize={15}
                        fstyle={'regular'}
                        text_color={theme_clr_white}
                        border={8}
                        btn_height={10}
                        background_color={theme_clr_10}
                    />

                </View>
            </View>
        </View>
    )
}

export default AssignedDeliveryCard

const styles = StyleSheet.create({
    main_view: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        borderWidth: 1,
        overflow: 'hidden',
        borderColor: theme_clr_light_grey,
        backgroundColor: theme_clr_10_transparent_0_max,
        borderRadius: 15,
        padding: 10,

        paddingTop: 25,
    },
    deliveries: {
        position: 'absolute',
        borderBottomRightRadius: 20,
        fontSize: 11,
        fontFamily: Poppins_Bold,
        color: theme_clr_dark,
        paddingHorizontal: 20,
        paddingLeft: 50,
        backgroundColor: theme_clr_4,
    },
    text_1: {
        fontSize: 12,
        fontFamily: Poppins_Bold,
        color: theme_clr_dark
    },
    text_2: {
        fontSize: 12,
        fontFamily: Poppins_Regular,
        color: theme_clr_dark,
        left: '20%'
    },
})