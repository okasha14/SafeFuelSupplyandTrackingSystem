import { Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { Montserrat_Bold, Montserrat_Regular, Poppins_Bold, Poppins_Regular, theme_clr_10, theme_clr_10_transparent, theme_clr_10_transparent_0, theme_clr_10_transparent_0_max, theme_clr_11, theme_clr_2, theme_clr_4, theme_clr_4_dark, theme_clr_4_transparent, theme_clr_6, theme_clr_6_light_transparent, theme_clr_dark, theme_clr_dull_white, theme_clr_matte, theme_clr_medium_grey, theme_clr_white, width } from '../../../style_sheet/styles'
import LinearGradient from 'react-native-linear-gradient'
import IconComponent from '../Icon_Component/IconComponent'

const NotificationCard = ({ notification }) => {

    console.log('notification', notification);

    const dateObj = new Date(notification.sent_date);

    const date = dateObj.toISOString().split('T')[0];

    const timeOptions = { hour: '2-digit', minute: '2-digit', hour12: true };
    const timeWithAMPM = dateObj.toLocaleTimeString('en-US', timeOptions);



    return (
        <View style={[styles.main_view, {
            backgroundColor: notification.heading == 'Alert' ? theme_clr_4_transparent :
                notification.heading == 'Route Deviation' ?
                    theme_clr_6_light_transparent :
                    theme_clr_10_transparent_0_max,
        }]}>

            <View style={{ alignSelf: 'flex-start', backgroundColor: theme_clr_white, borderWidth: 1, borderRadius: 1000, padding: 13 }}>


                {notification.heading == 'Alert' ?
                    <IconComponent name={'Feather'} icon={'alert-triangle'} size={25} color={theme_clr_4} /> :
                    notification.heading == 'Route Deviation' ?
                        <IconComponent name={'MaterialIcons'} icon={'route'} size={25} color={theme_clr_6} /> :
                        <IconComponent name={'MaterialCommunityIcons'} icon={'truck'} size={25} color={theme_clr_10} />
                }
            </View>

            <View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: width / 1.4, alignItems: 'center' }}>
                    <Text style={[styles.text, { fontFamily: Poppins_Bold, width: 'auto' }]}>{notification.heading.includes('#') ? 'Order' + notification.heading : notification.heading}</Text>
                    <Text style={[styles.date_time, {
                        alignSelf: 'flex-start',
                        color: notification.heading == 'Alert' ? theme_clr_4_dark :
                            notification.heading == 'Route Deviation' ? theme_clr_2 :
                                theme_clr_11

                    }]}>{date}</Text>
                </View>

                <Text style={styles.text}>{notification.message}</Text>
                <Text style={[styles.date_time, {
                    alignSelf: 'flex-end', fontFamily: Montserrat_Regular,
                    color: notification.heading == 'Alert' ? theme_clr_4_dark :
                        notification.heading == 'Route Deviation' ? theme_clr_2 :
                            theme_clr_11
                }]}>{timeWithAMPM}</Text>


            </View>
        </View>
    )
}

export default NotificationCard

const styles = StyleSheet.create({
    main_view: {
        flexDirection: 'row',
        alignItems: 'center',
        opacity: .8,
        gap: 10,
        borderWidth: 1,
        borderRadius: 10,
        borderColor: theme_clr_matte,
        padding: 10
    },
    text: {
        fontSize: 12,
        fontFamily: Poppins_Regular,
        // backgroundColor: 'pink',
        width: width / 1.4
    },
    date_time: {
        fontSize: 10,
        fontFamily: Montserrat_Bold,
    },
})