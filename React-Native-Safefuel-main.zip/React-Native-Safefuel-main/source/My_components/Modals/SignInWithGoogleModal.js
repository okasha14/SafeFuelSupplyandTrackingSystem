import React, { useEffect, useState } from 'react';
import { Modal, View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Montserrat_Bold, Montserrat_Regular, theme_clr_10, theme_clr_3, theme_clr_5_medium, theme_clr_dull_white, theme_clr_grey_2, theme_clr_light_grey, theme_clr_matte, theme_clr_medium_grey, theme_clr_white, width } from '../../../style_sheet/styles';
import AppButton from '../Buttons/AppButton';
import DropdownType1 from '../Dropdowns/DropdownType1';
import Textinput from '../TextInputs/Textinput';

const SignInWithGoogleModal = ({ visible, setvisible, on_press = null, setPhone, setRole, setTankerNumber, setAvgfuel, setFuelcapacity }) => {

    const [phonemodal, setPhoneModal] = useState('')
    const [rolemodal, setRoleModal] = useState('Owner')
    const [tankernumbermodal, setTankerNumberModal] = useState('')
    const [avgfuelmodal, setAvgfuelModal] = useState('')
    const [fuelcapacitymodal, setFuelcapacityModal] = useState('')


    useEffect(() => {
        setPhone(phonemodal)
        setRole(rolemodal)
        setTankerNumber(tankernumbermodal)
        setAvgfuel(avgfuelmodal)
        setFuelcapacity(fuelcapacitymodal)
    }, [phonemodal, rolemodal, tankernumbermodal, avgfuelmodal, fuelcapacitymodal])

    useEffect(() => {
        if (rolemodal == 'Owner') {
            setTankerNumberModal('')
            setAvgfuelModal('')
            setFuelcapacity('')
        }
    }, [rolemodal])

    return (
        <Modal transparent={true} visible={visible} animationType="slide">
            <View style={styles.modalContainer}>
                <View style={styles.modalContent}>

                    <Text style={styles.title}>Enter Your Details</Text>

                    <Textinput
                        text={'Phone Number'}
                        place_holder={'Enter your phone no.'}
                        set_val={setPhoneModal}
                        max_length={11}
                        input_mode={'numeric'}
                        val={phonemodal}
                    />

                    <DropdownType1
                        title={`Select Role`}
                        set_seleted_option={setRoleModal}
                        seleted_option={rolemodal}
                        data_list={[
                            { data: 'Owner' },
                            { data: 'Driver' },
                        ]}
                        dropdown_height={100}
                    />

                    {rolemodal == 'Driver' &&
                        <>                        <Textinput
                            text={'Tanker Number'}
                            place_holder={'Enter tanker no.'}
                            set_val={setTankerNumberModal}
                            val={tankernumbermodal}
                        />

                            <Textinput
                                text={'Avg. Fuel Consumption( per k/m )'}
                                place_holder={'Enter fuel consumption'}
                                set_val={setAvgfuelModal}
                                val={avgfuelmodal}
                                input_mode={'numeric'}
                            />

                            <Textinput
                                text={'Tanker Fuel Capacity'}
                                place_holder={'Enter fuel capacity'}
                                set_val={setFuelcapacityModal}
                                val={fuelcapacitymodal}
                                input_mode={'numeric'}
                            />
                        </>}


                    <View style={{ marginVertical: 10 }} />

                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Image
                            source={require('../../Assets/images/google.png')}
                            style={{ zIndex: 2, left: 10, width: 50, height: 50, resizeMode: 'contain' }}
                        />

                        <View style={{ width: width / 1.13, right: 50 }}>
                            <AppButton
                                on_press={() => on_press()}
                                text_color={theme_clr_matte} background_color={theme_clr_white} border_color={theme_clr_10} boxwidth={12} border={10} fsize={15} text="Sign In" btn_height={13} />
                        </View>
                    </View>


                    <AppButton
                        on_press={() => setvisible(false)}
                        text_color="#fff" background_color={theme_clr_5_medium} boxwidth={12} border={10} fsize={15} text="Cancel" btn_height={13} />


                </View>
            </View>
        </Modal>
    );
};

export default SignInWithGoogleModal;

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
        // alignItems: 'center',
        backgroundColor: theme_clr_white,
        borderTopLeftRadius: 16,
        borderTopRightRadius: 16,
        paddingVertical: 40,
        // paddingBottom: 100,
        paddingHorizontal: 20,
        gap: 10
    },
    title: {
        fontSize: 16,
        color: theme_clr_medium_grey,
        fontFamily: Montserrat_Bold,
        alignSelf: 'center',
        // width: '50%',
        paddingBottom: 20
    },

});

