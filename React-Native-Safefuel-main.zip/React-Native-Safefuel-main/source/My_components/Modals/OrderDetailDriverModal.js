import React from 'react';
import { Modal, View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { width, height, theme_clr_2, Poppins_Bold, theme_clr_white, Montserrat_Bold, theme_clr_10, theme_clr_dark, Poppins_Regular, theme_clr_11, Montserrat_Regular, theme_clr_10_light } from '../../../style_sheet/styles';
import IconComponent from '../Icon_Component/IconComponent';

const OrderDetailDriverModal = ({ visible, set_visible, data }) => {

    console.log('data order model', data);

    const dateStr = data.journey_started_date;
    const date = new Date(dateStr);

    const options = { month: "long", day: "numeric", year: "numeric" };
    const formattedDate = date.toLocaleDateString("en-US", options);

    let hours = date.getHours();
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    const period = hours >= 12 ? "PM" : "AM";

    hours = hours % 12 || 12;
    const formattedTime = `${hours}:${minutes}:${seconds} ${period}`;

    console.log("Date:", formattedDate);   // April 21 2025
    console.log("Time:", formattedTime);   // 6:10 AM


    return (
        <Modal
            transparent
            visible={visible}
            animationType="fade"
            onRequestClose={() => set_visible(!visible)}
        >
            <View style={styles.modalOverlay}>
                <View style={styles.modalContainer}>

                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Text style={styles.order_text}>Order  #{data?.order_number}</Text>

                        <TouchableOpacity
                            style={{ backgroundColor: theme_clr_dark, borderRadius: 5, padding: 2 }}
                            onPress={() => set_visible(!visible)} >
                            <IconComponent name="Ionicons" icon="close" size={24} color="#fff" />
                        </TouchableOpacity>

                    </View>

                    <ScrollView
                        showsVerticalScrollIndicator={false}
                        style={{ marginVertical: 10 }}>

                        {/* <Text style={[styles.text_1,{fontSize:16,color:theme_clr_2,backgroundColor:theme_clr_white}]}>{dataa?.stable_versions.length==0?`Unstable`:`Stable`}</Text> */}

                        <Text style={styles.text_1}>Driver Name :
                            <Text style={styles.text_2}> {data.u_name}</Text></Text>

                        <Text style={styles.text_1}>Fuel Type :
                            <Text style={styles.text_2}> {data.fuel_type}</Text></Text>

                        <Text style={styles.text_1}>Fuel Quantity :
                            <Text style={styles.text_2}> {data.quantity} Liters</Text></Text>

                        <Text style={styles.text_1}>Fuel Price :
                            <Text style={styles.text_2}> {data.price} PKR</Text></Text>

                        <Text style={styles.text_1}>Humidity :
                            <Text style={styles.text_2}> {data.humidity} %</Text></Text>

                        <Text style={styles.text_1}>Temperature :
                            <Text style={styles.text_2}> {data.temperature} °C</Text></Text>

                        <Text style={styles.text_1}>Drop Address :
                            <Text style={styles.text_2}> {data.drop_address}</Text></Text>

                        <Text style={styles.text_1}>Journey Started :
                            <Text style={styles.text_2}> {data.journey_started_date ? formattedDate +' '+formattedTime : `Not yet started .`}</Text></Text>


                        <Text style={styles.text_1}>Status :
                            <Text style={styles.text_2}> {data.status}</Text></Text>



                    </ScrollView>



                </View>

            </View>
        </Modal>
    );
};

export default OrderDetailDriverModal;

const styles = StyleSheet.create({
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.8)',
        justifyContent: 'center',
        alignItems: 'center'
    },
    modalContainer: {
        width: width * 0.9,
        height: height * 0.45,
        padding: 20,
        paddingBottom: 5,
        backgroundColor: theme_clr_10_light,
        borderRadius: 15,
        borderColor: theme_clr_white,
        borderWidth: .5,
    },
    order_text: {
        fontSize: 15,
        fontFamily: Montserrat_Bold,
        color: theme_clr_white,
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: 5,
        backgroundColor: theme_clr_dark,
        textTransform: 'uppercase'
    },
    text_1: {
        fontSize: 15,
        fontFamily: Poppins_Bold,
        color: theme_clr_11,
        paddingVertical: 4
    },
    text_2: {
        fontSize: 12,
        fontFamily: Montserrat_Regular,
        color: theme_clr_dark,
        left: '20%'
    },

});
