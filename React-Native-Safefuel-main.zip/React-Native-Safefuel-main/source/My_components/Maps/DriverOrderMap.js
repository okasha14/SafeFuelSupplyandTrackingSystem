import React, { useEffect, useState, useRef } from 'react';
import { StyleSheet, View, Text, Image, TouchableWithoutFeedback } from 'react-native';
import MapView, { Marker, Polyline, Circle } from 'react-native-maps';
import { requestLocationPermission } from '../../../HelperFunctions/Permissions_File/Permissions';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import Geolocation from '@react-native-community/geolocation';

const DriverOrderMap = ({ routeData, onMapTouchStart, onMapTouchEnd }) => {
    const [location, setLocation] = useState(null);
    const [region, setRegion] = useState(null); // State to manage region
    const [latitudeDelta, setLatitudeDelta] = useState(0.05); // State for latitudeDelta
    const [longitudeDelta, setLongitudeDelta] = useState(0.05); // State for longitudeDelta
    const mapRef = useRef(null);
    const markerRef = useRef(null);

    const getLocation = async () => {
        const hasPermission = await requestLocationPermission();
        if (!hasPermission) return;

        Geolocation.getCurrentPosition(
            (position) => {
                const newLocation = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                };

                // Set initial region and move camera to truck only once
                if (!region) {
                    const newRegion = {
                        ...newLocation,
                        latitudeDelta,
                        longitudeDelta,
                    };
                    setRegion(newRegion);
                    setTimeout(() => {
                        if (mapRef.current) {
                            mapRef.current.animateToRegion(newRegion, 1000);
                        }
                    }, 500);
                }

                // Smoothly animate truck marker if possible
                if (markerRef.current?.animateMarkerToCoordinate) {
                    markerRef.current.animateMarkerToCoordinate(newLocation, 2000);
                }

                setLocation(newLocation);

                // Check proximity to endpoint (200 meters)
                const distance = calculateDistance(
                    newLocation.latitude,
                    newLocation.longitude,
                    routeData.end_latitude,
                    routeData.end_longitude
                );

                if (distance <= 200) {
                    console.log('Driver is within 200 meters of the end point');
                }
            },
            (error) => console.error('Location error:', error),
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
        );
    };

    const calculateDistance = (lat1, lon1, lat2, lon2) => {
        const R = 6371000;
        const φ1 = (lat1 * Math.PI) / 180;
        const φ2 = (lat2 * Math.PI) / 180;
        const Δφ = ((lat2 - lat1) * Math.PI) / 180;
        const Δλ = ((lon2 - lon1) * Math.PI) / 180;

        const a =
            Math.sin(Δφ / 2) ** 2 +
            Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return R * c;
    };

    useEffect(() => {
        getLocation(); // Initial fetch
        const intervalId = setInterval(() => {
            getLocation();
        }, 5000);

        return () => clearInterval(intervalId);
    }, []);

    if (!routeData || !routeData.start_latitude || !routeData.end_latitude) {
        return (
            <View style={styles.container}>
                <Text style={styles.noRouteText}>No route data available</Text>
            </View>
        );
    }

    const waypoints = Array.isArray(routeData.waypoints)
        ? routeData.waypoints
        : JSON.parse(routeData.waypoints || '[]');

    const allCoordinates = [
        { latitude: routeData.start_latitude, longitude: routeData.start_longitude },
        ...waypoints,
        { latitude: routeData.end_latitude, longitude: routeData.end_longitude }
    ];

    // Function to handle region changes (e.g., zooming)
    const handleRegionChange = (newRegion) => {
        // Update delta values based on region change but don't force the map to re-fetch location
        setLatitudeDelta(newRegion.latitudeDelta);
        setLongitudeDelta(newRegion.longitudeDelta);
    };

    return (
        <GestureHandlerRootView>
            <TouchableWithoutFeedback
                onPressIn={onMapTouchStart}
                onPressOut={onMapTouchEnd}
            >
                <View style={styles.container}>
                    <MapView
                        ref={mapRef}
                        style={styles.map}
                        onTouchStart={onMapTouchStart}
                        onTouchEnd={onMapTouchEnd}
                        onRegionChangeComplete={handleRegionChange} // Update deltas on region change
                    >
                        {location && (
                            <Marker
                                ref={markerRef}
                                coordinate={location}
                                title="Truck"
                            >
                                <Image
                                    source={require('../../Assets/images/truck.png')}
                                    style={{ width: 35, height: 40 }}
                                    resizeMode="contain"
                                />
                            </Marker>
                        )}

                        <Marker
                            coordinate={{ latitude: routeData.start_latitude, longitude: routeData.start_longitude }}
                            title="Start Point"
                        >
                            <Image
                                source={require('../../Assets/images/start.png')}
                                style={{ width: 35, height: 40 }}
                                resizeMode="contain"
                            />
                        </Marker>

                        <Marker
                            coordinate={{ latitude: routeData.end_latitude, longitude: routeData.end_longitude }}
                            title="End Point"
                        >
                            <Image
                                source={require('../../Assets/images/fueldrop.png')}
                                style={{ width: 30, height: 30 }}
                                resizeMode="contain"
                            />
                        </Marker>

                        <Circle
                            center={{
                                latitude: routeData.end_latitude,
                                longitude: routeData.end_longitude
                            }}
                            radius={200} // ✅ Updated to 200 meters
                            strokeWidth={2}
                            strokeColor="#00FF00"
                            fillColor="rgba(0, 255, 0, 0.2)"
                        />

                        {allCoordinates.length > 1 && (
                            <Polyline
                                coordinates={allCoordinates}
                                strokeColor="#0000FF"
                                strokeWidth={3}
                            />
                        )}
                    </MapView>
                </View>
            </TouchableWithoutFeedback>
        </GestureHandlerRootView>
    );
};

const styles = StyleSheet.create({
    container: {
        height: 300,
        width: '100%',
        borderRadius: 10,
        overflow: 'hidden',
        marginBottom: 5,
        borderWidth: 0.5
    },
    map: {
        ...StyleSheet.absoluteFillObject,
    },
    noRouteText: {
        textAlign: 'center',
        padding: 20,
        color: 'gray',
    },
});

export default DriverOrderMap;
