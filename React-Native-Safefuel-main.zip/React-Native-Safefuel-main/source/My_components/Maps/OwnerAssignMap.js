import React, { useEffect, useState } from 'react';
import { StyleSheet, TouchableWithoutFeedback, View, Alert, Text, TouchableOpacity } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import MapView, { Marker, Polyline } from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import { requestLocationPermission } from '../../../HelperFunctions/Permissions_File/Permissions';
import { ors_api_key, Poppins_Bold, Poppins_Regular, theme_clr_1, theme_clr_10, theme_clr_white, width } from '../../../style_sheet/styles';
import AppButton from '../Buttons/AppButton';

const OwnerAssignMap = ({ setScrollEnabled, onRouteSave, signal }) => {
  const [location, setLocation] = useState(null);
  const [routeCoordinates, setRouteCoordinates] = useState([]);
  const [routeData, setRouteData] = useState({
    start_latitude: 0,
    start_longitude: 0,
    end_latitude: 0,
    end_longitude: 0,
    waypoints: []
  });
  const [markers, setMarkers] = useState({
    start: null,
    end: null
  });
  const [isSelecting, setIsSelecting] = useState(null); // 'start' or 'end'

  const getLocation = async () => {
    const hasPermission = await requestLocationPermission();
    if (!hasPermission) return;

    Geolocation.getCurrentPosition(
      (position) => {
        const newLocation = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        };
        setLocation(newLocation);
      },
      (error) => console.error(error),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  };

  const fetchRoute = async (start, end) => {
    try {
      if (!start || !end) {
        setRouteCoordinates([]);
        return;
      }

      const url = `https://api.openrouteservice.org/v2/directions/driving-hgv?api_key=${ors_api_key}&start=${start.longitude},${start.latitude}&end=${end.longitude},${end.latitude}`;

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const coordinates = data.features[0].geometry.coordinates.map(coord => ({
        latitude: coord[1],
        longitude: coord[0]
      }));

      setRouteCoordinates(coordinates);

      // Update route data for database
      setRouteData(prev => ({
        ...prev,
        start_latitude: start.latitude,
        start_longitude: start.longitude,
        end_latitude: end.latitude,
        end_longitude: end.longitude,
        waypoints: coordinates.slice(1, -1) // Exclude start and end points
      }));

    } catch (error) {
      console.error('Error fetching route:', error);
      Alert.alert('Error', 'Could not fetch route. Please try again.');
    }
  };

  const handleMapPress = (e) => {
    if (!isSelecting) return;

    const newPoint = e.nativeEvent.coordinate;
    updateMarker(isSelecting, newPoint);
  };

  const handleMarkerPress = (type) => {
    // Toggle marker - if clicked, remove it
    updateMarker(type, null);
  };

  const updateMarker = (type, point) => {
    setMarkers(prev => {
      const newMarkers = {
        ...prev,
        [type]: point
      };

      // Automatically fetch route when both markers exist
      if (newMarkers.start && newMarkers.end) {
        fetchRoute(newMarkers.start, newMarkers.end);
      } else {
        setRouteCoordinates([]);
      }

      return newMarkers;
    });

    setIsSelecting(null);
  };

  const saveRouteToDB = () => {
    if (!markers.start || !markers.end) {
      Alert.alert('Error', 'Please set both start and end points');
      return;
    }

    if (onRouteSave) {
      onRouteSave(routeData);
    }
  };

  useEffect(() => {
    if (markers.start && markers.end && routeCoordinates.length > 0) {
      saveRouteToDB();
    }
  }, [markers.start, markers.end, routeCoordinates]);


  useEffect(() => {
    if (signal && markers.start && markers.end && routeCoordinates.length > 0) {
      saveRouteToDB(); // Save before clearing
      setMarkers({ start: null, end: null });
      setRouteCoordinates([]);
    }
  }, [signal]);
  



  useEffect(() => {
    setTimeout(async () => {
      await getLocation();
    }, 1000);
  }, []);

  return (
    <GestureHandlerRootView>
      <TouchableWithoutFeedback
        onPressIn={() => setScrollEnabled(false)}
        onPressOut={() => setScrollEnabled(true)}
      >
        <View>
          <MapView
            style={styles.map}
            showsUserLocation
            initialRegion={{
              latitude: location?.latitude || 37.7749,
              longitude: location?.longitude || -122.4194,
              latitudeDelta: 0.05,
              longitudeDelta: 0.05,
            }}
            onPress={handleMapPress}
          >
            {markers.start && (
              <Marker
                coordinate={markers.start}
                title="Start Point"
                pinColor="green"
                onPress={() => handleMarkerPress('start')}
              />
            )}

            {markers.end && (
              <Marker
                coordinate={markers.end}
                title="End Point"
                pinColor="red"
                onPress={() => handleMarkerPress('end')}
              />
            )}

            {routeCoordinates.length > 0 && (
              <Polyline
                coordinates={routeCoordinates}
                strokeColor="#0000FF"
                strokeWidth={3}
              />
            )}
          </MapView>

          <View style={styles.controls}>

            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

              <View style={{ width: width / 2.4 }}>
                <AppButton
                  on_press={() => setIsSelecting('start')}
                  text={markers.start ? 'Change Start' : 'Set Start'}
                  fsize={12}
                  fstyle={'regular'}
                  text_color={'#fff'}
                  border={8}
                  btn_height={10}
                  background_color={isSelecting === 'start' ? 'grey' : theme_clr_10}
                />
              </View>

              <View style={{ width: width / 2.4 }}>
                <AppButton
                  on_press={() => setIsSelecting('end')}
                  text={markers.end ? 'Change End' : 'Set End'}
                  fsize={12}
                  fstyle={'regular'}
                  text_color={'#fff'}
                  border={8}
                  btn_height={10}
                  background_color={isSelecting === 'end' ? 'grey' : theme_clr_10}
                />
              </View>
            </View>



          </View>

          {isSelecting && (
            <View style={styles.instructionContainer}>
              <Text style={styles.instructionText}>
                Tap on the map to set {isSelecting} point
              </Text>
            </View>
          )}
        </View>




      </TouchableWithoutFeedback>
    </GestureHandlerRootView>
  );
};

export default OwnerAssignMap;

const styles = StyleSheet.create({
  map: {
    height: width * .8,
    width: width / 1.06,
    backgroundColor: theme_clr_white,
  },
  controls: {
    padding: 10,
    borderTopWidth: 1,
    borderColor: theme_clr_10,
    gap: 10,
    backgroundColor: '#f5f5f5',
  },
  controlButton: {
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  startButton: {
    backgroundColor: 'green',
  },
  endButton: {
    backgroundColor: 'red',
  },
  saveButton: {
    backgroundColor: 'blue',
  },
  activeButton: {
    backgroundColor: 'grey',
    borderWidth: 2,
    borderColor: 'black',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  instructionContainer: {
    padding: 10,
    backgroundColor: 'rgba(0,0,0,0.7)',
    position: 'absolute',
    top: 10,
    alignSelf: 'center',
    borderRadius: 5,
  },
  instructionText: {
    color: 'white',
    fontSize: 10,
    color: theme_clr_white,
    fontFamily: Poppins_Regular
  },
});