import React, { useEffect, useState, useRef, useCallback } from 'react';
import { StyleSheet, View, Text, Image, StatusBar, TouchableOpacity } from 'react-native';
import MapView, { Marker, Polyline, Circle } from 'react-native-maps';
import { api_url, height, Montserrat_Bold, Montserrat_Regular, Poppins_Bold, theme_clr_1, theme_clr_10, theme_clr_10_transparent_0_max, theme_clr_3, theme_clr_5, theme_clr_5_medium, theme_clr_6, theme_clr_7, theme_clr_8, theme_clr_8_dark, theme_clr_dark, theme_clr_dull_white, theme_clr_grey_1, theme_clr_white, width } from '../../../style_sheet/styles';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import IconComponent from '../../My_components/Icon_Component/IconComponent';

const OwnerOrderMapScreen = ({ route }) => {
    const navigation = useNavigation();
    const { routeData } = route.params || {};

    // Remove the console log that's causing the issue
    // console.log('sdsadasds', routeData);

    const [location, setLocation] = useState(null);
    const [region, setRegion] = useState(null);
    const [latitudeDelta, setLatitudeDelta] = useState(0.01);
    const [longitudeDelta, setLongitudeDelta] = useState(0.01);
    const [loading, setLoading] = useState(true);

    const mapRef = useRef(null);
    const markerRef = useRef(null);
    const pollingRef = useRef(null);

    useFocusEffect(
        useCallback(() => {
            StatusBar.setBackgroundColor(theme_clr_white);
            StatusBar.setTranslucent(false);
            StatusBar.setBarStyle('dark-content');
        }, [])
    );

    const fetchDriverLocation = async () => {
        try {
            const response = await fetch(`${api_url}/fetch_driver_location`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    driverId: routeData.driver_id
                }),
            });
    
            let data = await response.json();
            
            if (data.data && data.data.t_latitude && data.data.t_longitude) {
                // Update truck location with data from API
                setLocation({ 
                    latitude: parseFloat(data.data.t_latitude), 
                    longitude: parseFloat(data.data.t_longitude)
                });
                
                setLoading(false);
            }
        } catch (error) {
            console.error('Failed to fetch driver location:', error);
        }
    };

    useEffect(() => {
        if (routeData?.start_latitude && routeData?.start_longitude) {
            const newRegion = {
                latitude: parseFloat(routeData.start_latitude),
                longitude: parseFloat(routeData.start_longitude),
                latitudeDelta: 0.03,
                longitudeDelta: 0.03
            };
            setRegion(newRegion);
            
            // Set initial location from route data
            setLocation({ 
                latitude: parseFloat(routeData.start_latitude), 
                longitude: parseFloat(routeData.start_longitude) 
            });
    
            if (mapRef.current) {
                mapRef.current.animateToRegion(newRegion, 1000);
            }
            
            setLoading(false);
        }
    }, [routeData]);

    useEffect(() => {
        // Fetch driver location immediately when component mounts
        fetchDriverLocation();
        
        // Start polling
        pollingRef.current = setInterval(fetchDriverLocation, 5000);
    
        // Cleanup
        return () => {
            if (pollingRef.current) {
                clearInterval(pollingRef.current);
            }
        };
    }, []);

    if (!routeData || !routeData.start_latitude || !routeData.end_latitude) {
        return (
            <View style={styles.container}>
                <Text style={styles.noRouteText}>No valid route data available</Text>
            </View>
        );
    }

    if (loading && !location) {
        return (
            <View style={[styles.container, { backgroundColor: theme_clr_10_transparent_0_max }]}>
                <Text style={{ fontSize: 18, fontFamily: Poppins_Bold, color: theme_clr_dark }}>Loading map data...</Text>
            </View>
        );
    }

    const parseWaypoints = () => {
        try {
            return Array.isArray(routeData.waypoints)
                ? routeData.waypoints
                : JSON.parse(routeData.waypoints || '[]');
        } catch {
            return [];
        }
    };

    const waypoints = parseWaypoints();
    const allCoordinates = [
        { latitude: parseFloat(routeData.start_latitude), longitude: parseFloat(routeData.start_longitude) },
        ...waypoints,
        { latitude: parseFloat(routeData.end_latitude), longitude: parseFloat(routeData.end_longitude) }
    ].filter(point => point.latitude && point.longitude);

    const handleRegionChange = (newRegion) => {
        setLatitudeDelta(newRegion.latitudeDelta);
        setLongitudeDelta(newRegion.longitudeDelta);
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerContainer}>
                <TouchableOpacity
                    onPress={() => { navigation.goBack(); }}
                    style={styles.back_btn}
                >
                    <IconComponent
                        name={'MaterialIcons'}
                        icon={'arrow-back'}
                        size={18}
                        color={theme_clr_white}
                    />
                    <Text style={styles.backText}>back</Text>
                </TouchableOpacity>
            </View>

            <MapView
                ref={mapRef}
                style={styles.map}
                initialRegion={region}
                onRegionChangeComplete={handleRegionChange}
                followsUserLocation={true}
            >
                {location && (
                    <Marker
                        ref={markerRef}
                        coordinate={location}
                        title="Truck"
                    >
                        <Image
                            source={require('../../Assets/images/truck.png')}
                            style={styles.truckIcon}
                        />
                    </Marker>
                )}

                <Marker
                    coordinate={{
                        latitude: parseFloat(routeData.start_latitude),
                        longitude: parseFloat(routeData.start_longitude)
                    }}
                    title="Start Point"
                >
                    <Image
                        source={require('../../Assets/images/start.png')}
                        style={styles.startIcon}
                    />
                </Marker>

                <Marker
                    coordinate={{
                        latitude: parseFloat(routeData.end_latitude),
                        longitude: parseFloat(routeData.end_longitude)
                    }}
                    title="Destination"
                >
                    <Image
                        source={require('../../Assets/images/fueldrop.png')}
                        style={styles.endIcon}
                    />
                </Marker>

                <Circle
                    center={{
                        latitude: parseFloat(routeData.end_latitude),
                        longitude: parseFloat(routeData.end_longitude)
                    }}
                    radius={200}
                    strokeWidth={2}
                    strokeColor="lightgreen"
                    fillColor="rgba(0, 255, 0, 0.2)"
                />

                {allCoordinates.length > 1 && (
                    <Polyline
                        coordinates={allCoordinates}
                        strokeColor="#0000FF"
                        strokeWidth={3}
                    />
                )}
            </MapView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    map: {
        ...StyleSheet.absoluteFillObject,
    },
    noRouteText: {
        textAlign: 'center',
        padding: 20,
        color: 'gray',
    },
    headerContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '83%',
        position: 'absolute',
        top: 10,
        left: '15%',
        zIndex: 1,
    },
    back_btn: {
        flexDirection: 'row',
        backgroundColor: theme_clr_dark,
        borderRadius: 100,
        paddingVertical: 8,
        paddingLeft: 10,
        paddingRight: 20,
        alignSelf: 'flex-start',
        alignItems: 'center',
        gap: 5
    },
    backText: {
        fontSize: 10,
        color: theme_clr_white,
        fontFamily: Montserrat_Bold
    },
    truckIcon: {
        top: 15,
        width: 30,
        height: 20
    },
    startIcon: {
        width: 35,
        height: 40
    },
    endIcon: {
        width: 30,
        height: 30
    },
});

export default OwnerOrderMapScreen;