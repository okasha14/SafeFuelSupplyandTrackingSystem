import { Alert, RefreshControl, SafeAreaView, StatusBar, StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { api_url, height, Montserrat_Regular, theme_clr_10, theme_clr_10_light, theme_clr_10_transparent_0, theme_clr_dark, theme_clr_white, width } from '../../../style_sheet/styles';
import LinearGradient from 'react-native-linear-gradient';
import AppHeader from '../../My_components/Header/AppHeader';
import { ScrollView } from 'react-native-gesture-handler';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import Textinput from '../../My_components/TextInputs/Textinput';
import AppButton from '../../My_components/Buttons/AppButton';
import DropdownType1 from '../../My_components/Dropdowns/DropdownType1';
import CaledarModal from '../../My_components/Modals/CaledarModal';
import OwnerAssignMap from '../../My_components/Maps/OwnerAssignMap';
import { EnableLocationPopup, requestLocationPermission } from '../../../HelperFunctions/Permissions_File/Permissions';
import RealTimeMap from './RealTimeMap';
import { useSelector } from 'react-redux';

const AssignDeliveries = () => {
  const navigation = useNavigation()

  const userdata = useSelector(state => state.userdatais.userdata);

  const [scrollEnabled, setScrollEnabled] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [fueltype, setFueltype] = useState('')
  const [scheduledate, setScheduledate] = useState([]);
  const [price, setPrice] = useState('')
  const [quantity, setQuantity] = useState('')
  const [address, setAddress] = useState('')
  const [routedata, setRoutedata] = useState('')
  const [drivers, setDrivers] = useState([])
  const [selecteddriver, setSelecteddriver] = useState('')

  const [fetchroutesignal, setFetchroutesignal] = useState('')


  const [orderdara, setOrderdara] = useState('')


  useFocusEffect(
    React.useCallback(() => {
      StatusBar.setBackgroundColor(theme_clr_white);
      StatusBar.setTranslucent(false);
      StatusBar.setBarStyle('dark-content');
    }, [])
  );

  const fetchAvalibleDrivers = async () => {

    try {
      const response = await fetch(`${api_url}/fetchDrivers`);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      setDrivers(result)
      console.log('drives:::', result);

    } catch (err) {
    } finally {
    }


  }


  useEffect(() => {
    setTimeout(async () => {

      await EnableLocationPopup()
      await fetchAvalibleDrivers()
      // await requestLocationPermission()
    }, 1000);

  }, [])

  useEffect(() => {
    // Find the selected driver object from drivers list
    const selectedDriverData = drivers.find(driver => driver.u_name === selecteddriver) || {};

    // Update orderdara with selected driver details, user data, and other form data
    setOrderdara({
      driver: selectedDriverData, // Store full driver object
      user: userdata, // Include user data
      quantity,
      price,
      scheduledate,
      fueltype,
      address,
      routedata
    });

    console.log("Updated Order Data:", {
      driver: selectedDriverData,
      user: userdata,
      quantity,
      price,
      scheduledate,
      fueltype,
      address,
      routedata
    });

  }, [selecteddriver, quantity, price, scheduledate, fueltype, address, routedata, drivers, userdata]);


  const handleAssigndelivery = async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const scheduledDate = new Date(
      scheduledate.year,
      scheduledate.month - 1,
      scheduledate.day
    );

    
    
    // Compare just the date portions (ignoring time)
    if (scheduledDate < today) {

      console.log('scheduledDate:', scheduledDate);
      console.log('Current Date:', today);
            Alert.alert('Invalid Date', 'The scheduled date cannot be in the past');
      return;
    }


    if (parseFloat(quantity) > parseFloat(drivers.find(d => d.u_name === selecteddriver)?.fuel_capacity)) {

      console.log(drivers.find(d => d.u_name === selecteddriver)?.fuel_capacity, '    ', quantity);

      Alert.alert('Fuel Capacity Exceeded !!')
      return
    }

    if (selecteddriver == 'Select Driver') {
      Alert.alert('Please Select a Driver !!')
      return
    }
    if (!price || !quantity || !address || !routedata) {
      Alert.alert('Please fill in all the fields before proceeding.');
      return;
    }

    try {

      const response = await fetch(`${api_url}/assignDelivery`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderdara),  // Send the orderdara state directly
      });

      if (!response.ok) {
        throw new Error(`Failed to assign delivery: ${response.status}`);
        return
      }

      // Handle successful response
      const result = await response.json();

      setAddress('')
      setPrice('')
      setQuantity('')

      setFetchroutesignal(prev => prev + 1);

      setRoutedata('');

      setSelecteddriver('Select Driver');

      await fetchAvalibleDrivers()
      // navigation.navigate('Home')
      navigation.navigate('Home', { refresh_page: Math.floor(10000 + Math.random() * 90000) })
      Alert.alert('Delivery assigned successfully');

    } catch (error) {
      console.error('Error assigning delivery:', error);
    }
  };



  return (
    <LinearGradient
      colors={[theme_clr_white, theme_clr_white, theme_clr_10_transparent_0]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.9, y: 0.9 }}
      style={{ flex: 'auto' }}
    >
      <AppHeader heading={'Assign Deliveries'} />

      <ScrollView
        scrollEnabled={scrollEnabled}
        contentContainerStyle={{ paddingHorizontal: 10, paddingTop: 10, paddingBottom: 100 }} showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={async () => {
              setRefreshing(true);
              await fetchAvalibleDrivers();
              setRefreshing(false);
            }}
          />

        }
      >

        {/* <Text>{fueltype}</Text>
        <Text>{scheduledate}</Text> */}

        {/* <Text>{selecteddriver}</Text> */}

        <View style={{ gap: 10 }}>

          <View style={{ width: width / 1.06 }}>
            <DropdownType1
              title={`Select Driver`}
              set_seleted_option={setSelecteddriver}
              seleted_option={selecteddriver}
              data_list={
                drivers.length > 0
                  ? drivers.map(driver => ({ data: driver.u_name }))
                  : [{ data: 'Select Driver' }]
              }
              dropdown_height={300}
            />

            {selecteddriver !== 'Select Driver' && (
              <Text style={{ backgroundColor: theme_clr_10_light, fontSize: 12, fontFamily: Montserrat_Regular, color: theme_clr_dark, marginLeft: 10, marginBottom: 5, alignSelf: 'flex-start', paddingVertical: 3, paddingHorizontal: 10, paddingRight: 50, borderBottomLeftRadius: 10, borderBottomRightRadius: 10 }}>
                FUEL CAPACITY : {drivers.find(d => d.u_name === selecteddriver)?.fuel_capacity || 'N/A'} Liters
              </Text>
            )}
          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View style={{ width: width / 2.2 }}>
              <DropdownType1
                title={`Fuel Type`}
                set_seleted_option={setFueltype}
                seleted_option={fueltype}
                data_list={[
                  { data: 'Petrol' },
                  { data: 'Diesel' },
                ]}
                dropdown_height={100}
              />
            </View>

            <View style={{ width: width / 2.2 }}>
              <CaledarModal title={'Schedule Date'} set_selected_date={setScheduledate} />

            </View>

          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View style={{ width: width / 2.2 }}>
              <Textinput
                text={'Price (PKR)'}
                place_holder={'Enter Price'}
                set_val={setPrice}
                input_mode={'numeric'}
                val={price}
              />
            </View>

            <View style={{ width: width / 2.2 }}>
              <Textinput
                text={'Quantity (Liters)'}
                place_holder={'Enter Quantity'}
                set_val={setQuantity}
                input_mode={'numeric'}
                val={quantity}
              />
            </View>


          </View>

          <Textinput
            text={'Destination Address'}
            place_holder={'Enter Address'}
            set_val={setAddress}
            val={address}
          />




        </View>
        {/* <Text>{JSON.stringify(routedata, null, 2)}</Text> */}


        {/* {routedata && */}
        <View style={styles.map_container}>
          <OwnerAssignMap setScrollEnabled={setScrollEnabled} onRouteSave={setRoutedata} signal={fetchroutesignal} />
        </View>
        {/* } */}

        <View style={{ marginTop: 30 }}>
          <AppButton
            on_press={async () => {
              await setFetchroutesignal(prev => prev + 1);
              setTimeout(async () => {
                await handleAssigndelivery();
              }, 500);
            }}
            text={'Assign'}
            fsize={15}
            fstyle={'regular'}
            text_color={'#fff'}
            border={8}
            btn_height={14}
            background_color={theme_clr_10}
          />
        </View>



        {/* Display the saved route */}
        {/* <View style={styles.display_map_container}>
          <Text style={styles.sectionTitle}>Saved Route</Text>
          <View style={{ height: 300, borderRadius: 10, overflow: 'hidden' }}>
            <RealTimeMap routeData={routedata} />
          </View>
        </View> */}


        {/* <View style={{paddingVertical:'.5%'}}/> */}

      </ScrollView>
    </LinearGradient>
  );
};
export default AssignDeliveries

const styles = StyleSheet.create({

  map_container: {
    zIndex: 2,
    borderWidth: 2,
    borderRadius: 10,
    borderColor: theme_clr_10,
    marginVertical: 20,
    height: width * .96,
    width: width / 1.06,
    overflow: 'hidden',
    backgroundColor: 'cyan',
  },



  display_map_container: {
    marginVertical: 10,
    width: '100%',
    minHeight: 400,  // Ensure enough space
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
});
