import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';

const RealTimeMap = ({ routeData }) => {
  if (!routeData || !routeData.start_latitude || !routeData.end_latitude) {
    return (
      <View style={styles.container}>
        <Text style={styles.noRouteText}>No route data available</Text>
      </View>
    );
  }

  // Convert waypoints from JSON string if needed
  const waypoints = Array.isArray(routeData.waypoints) 
    ? routeData.waypoints 
    : JSON.parse(routeData.waypoints || '[]');

  // Combine all coordinates for the polyline
  const allCoordinates = [
    { latitude: routeData.start_latitude, longitude: routeData.start_longitude },
    ...waypoints,
    { latitude: routeData.end_latitude, longitude: routeData.end_longitude }
  ];

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: routeData.start_latitude,
          longitude: routeData.start_longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }}
      >
        <Marker
          coordinate={{ latitude: routeData.start_latitude, longitude: routeData.start_longitude }}
          title="Start Point"
          pinColor="green"
        />
        
        <Marker
          coordinate={{ latitude: routeData.end_latitude, longitude: routeData.end_longitude }}
          title="End Point"
          pinColor="red"
        />
        
        {allCoordinates.length > 1 && (
          <Polyline
            coordinates={allCoordinates}
            strokeColor="#0000FF"
            strokeWidth={3}
          />
        )}
      </MapView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 250,
    width: '100%',
    borderRadius: 10,
    overflow: 'hidden',
    marginVertical: 10,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  noRouteText: {
    textAlign: 'center',
    padding: 20,
    color: 'gray',
  },
});

export default RealTimeMap;