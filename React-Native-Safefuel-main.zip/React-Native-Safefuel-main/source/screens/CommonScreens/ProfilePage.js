import { Image, StatusBar, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import LinearGradient from 'react-native-linear-gradient'
import { Montserrat_Bold, Montserrat_Regular, Poppins_Bold, Poppins_Regular, theme_clr_10, theme_clr_10_transparent_0, theme_clr_10_transparent_0_max, theme_clr_11, theme_clr_dark, theme_clr_light_grey, theme_clr_white, width } from '../../../style_sheet/styles'
import AppHeader from '../../My_components/Header/AppHeader'
import { ScrollView } from 'react-native-gesture-handler'
import { useFocusEffect } from '@react-navigation/native'
import { useSelector } from 'react-redux'

const ProfilePage = () => {
  const userdata = useSelector(state => state.userdatais.userdata);

  console.log(userdata);

  useFocusEffect(
    React.useCallback(() => {
      StatusBar.setBackgroundColor(theme_clr_10);
      StatusBar.setTranslucent(false)
      StatusBar.setBarStyle('dark-content');
    }, [])
  );

  return (
    <View style={{ backgroundColor: theme_clr_white, flex: 1 }}>
      <View style={{ zIndex: 2 }}>
        <AppHeader
          bar_color={theme_clr_white}
          background={theme_clr_10}
          heading={'Profile'} />
      </View>


      <View style={{ backgroundColor: theme_clr_10, height: 150, top: 0 }} />
      <View style={styles.white_cut_bar} />

      <ScrollView
        contentContainerStyle={{
          paddingHorizontal: 10,
          paddingBottom: 60
        }}
        style={styles.main_scroll_view}
        showsVerticalScrollIndicator={false}
      >


        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 15 }}>
          <View style={styles.img_view}>
            <Image
              style={{ height: width / 4, width: width / 4 }}
              source={require('../../Assets/images/fueldrop.png')} />
          </View>

          <View style={{ gap: 10 }}>

            <Text style={{ fontSize: width / 10, fontFamily: Poppins_Bold, marginLeft: 10, color: theme_clr_dark }}>{userdata?.u_role || `- - @gmail.com`}</Text>
            {/* <View>
              <Text style={{ fontSize: 15, fontFamily: Poppins_Bold, color: theme_clr_dark, width: width / 1.8 }}>{userdata?.u_name || `Loading . . .`}</Text>
              <Text style={{ fontSize: 15, fontFamily: Poppins_Regular, color: theme_clr_dark, fontStyle: 'italic' }}>{userdata?.u_email || `- - @gmail.com`}</Text>
            </View>

            <Text style={{ fontSize: 12, fontFamily: Poppins_Bold, color: theme_clr_dark }}>+92 {userdata?.u_phone || `XXXXXXXXXX`}</Text> */}
          </View>
        </View>


        <View style={{ paddingVertical: 20, paddingLeft: 15, gap: 2 }}>

          <Text style={styles.heading_tag}>User Info</Text>
          <Text style={styles.info_text}>Name :
            <Text style={{ color: theme_clr_10, fontFamily: Montserrat_Regular }}>
              {'  '}{userdata?.u_name || `- -`}</Text>
          </Text>

          <Text style={styles.info_text}>Email :
            <Text style={{ color: theme_clr_10, fontFamily: Montserrat_Regular }}>
              {'  '}{userdata?.u_email || `- -`}</Text>
          </Text>

          <Text style={styles.info_text}>Phone no :
            <Text style={{ color: theme_clr_10, fontFamily: Montserrat_Regular }}> {userdata?.u_phone || `XXXXXXXXXX`}</Text>
              {/* {'  +92 '}{userdata?.u_phone || `XXXXXXXXXX`}</Text> */}
          </Text>

          {userdata.u_role == 'Driver' &&
            <>
              <Text style={[styles.heading_tag, { marginTop: 20 }]}>Truck Info</Text>

              <Text style={styles.info_text}>Truck number :
                <Text style={{ color: theme_clr_10, fontFamily: Montserrat_Regular }}>
                  {'  '}{userdata?.tanker[0].tanker_number || `- -`}</Text>
              </Text>

              <Text style={styles.info_text}>Fuel Capacity :
                <Text style={{ color: theme_clr_10, fontFamily: Montserrat_Regular }}>
                  {'  '}{userdata?.tanker[0].fuel_capacity + ' Liters' || `- -`}</Text>
              </Text>

              <Text style={styles.info_text}>Avg. Fuel Consumption :
                <Text style={{ color: theme_clr_10, fontFamily: Montserrat_Regular }}>
                  {'  '}{userdata?.tanker[0].avg_fuel_consumption + ' Liters Per/Km' || `- -`}</Text>
              </Text>
            </>

          }
        </View>

      </ScrollView>

    </View>
  )
}

export default ProfilePage

const styles = StyleSheet.create({
  img_view: {
    borderWidth: 10,
    borderColor: theme_clr_10,
    backgroundColor: theme_clr_white,
    alignSelf: 'flex-start',
    borderRadius: 1000,
    padding: 5,
  },
  white_cut_bar: {
    backgroundColor: theme_clr_white,
    height: 150,
    width: width * 2,
    top: 80,
    left: -10,
    transform: [{ rotate: '-20deg' }],
    position: 'absolute',
    zIndex: 1
  },
  main_scroll_view: {
    position: 'absolute',
    top: 100,
    zIndex: 2,
    width: '100%',
  },
  info_text: {
    fontSize: 14,
    fontFamily: Poppins_Bold,
    color: theme_clr_dark,
  },
  heading_tag: {
    fontSize: 15,
    color: theme_clr_dark,
    fontFamily: Montserrat_Bold,
    backgroundColor: theme_clr_10_transparent_0_max,
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 15,
    marginVertical: 5,
    alignSelf: 'flex-start'
  },
})