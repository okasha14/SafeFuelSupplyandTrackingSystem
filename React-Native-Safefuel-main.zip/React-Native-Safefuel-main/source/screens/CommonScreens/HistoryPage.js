import { RefreshControl, ScrollView, StatusBar, StyleSheet, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import { api_url, Poppins_Regular, theme_clr_10_transparent_0, theme_clr_dark, theme_clr_white } from '../../../style_sheet/styles';
import { useFocusEffect } from '@react-navigation/native';
import LinearGradient from 'react-native-linear-gradient';
import AppHeader from '../../My_components/Header/AppHeader';
import HistoryCard from '../../My_components/Cards/HistoryCard';
import ReceiptModal from '../../My_components/Modals/ReceiptModal';
import { useSelector } from 'react-redux';
import DefaultLoading from '../../My_components/Loading/DefaultLoading';

const HistoryPage = () => {

  const userdata = useSelector(state => state.userdatais.userdata);

  const [historydata, setHistorydata] = useState([]);

  const [orderreciept, setorderreciept] = useState(null);
  const [recieptmodal, setRecieptmodal] = useState(false);

  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(false)


  const fetch_history = async () => {

    console.log(userdata);
    setRefreshing(true)
    try {
      const response = await fetch(`${api_url}/get_history_data`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: userdata.id,userRole:userdata.u_role }),
      });

      if (!response.ok) {
        throw new Error(`Server timed out`);
      }

      let data = await response.json();

      setHistorydata(data)      


    } catch { setRefreshing(false) }
    finally {
      setRefreshing(false)
    }
  }


  useFocusEffect(
    React.useCallback(() => {
      StatusBar.setBackgroundColor(theme_clr_white);
      StatusBar.setTranslucent(false);
      StatusBar.setBarStyle('dark-content');
    }, [])
  );

  useEffect(() => {

    fetch_history()
  }, [userdata])


  return (
    <LinearGradient
      colors={[theme_clr_white, theme_clr_white, theme_clr_10_transparent_0]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.9, y: 0.9 }}
      style={{ height: '100%' }}
    >
      <AppHeader heading={'History'} />
      <DefaultLoading visible={loading} />

      <ScrollView contentContainerStyle={{ paddingHorizontal: 10, paddingTop: 10, paddingBottom: 60 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={fetch_history}
          />

        }
      >

        {historydata.map((item, index) => (
          <HistoryCard
            key={index}
            on_press={() => {
              setorderreciept(item);
              setRecieptmodal(true);  // Open modal when clicking a card
            }}
            history={item}
          />
        ))}

        {historydata.length === 0 && (
          <Text style={{ fontSize: 20, fontFamily: Poppins_Regular, color: theme_clr_dark, paddingTop: 50, textAlign: 'center' }}>
            No History Available !
          </Text>
        )}
      </ScrollView>

      <ReceiptModal
        visible={recieptmodal}
        order={orderreciept}
        onClose={() => setRecieptmodal(false)}
      />
    </LinearGradient>
  );
};

export default HistoryPage;
