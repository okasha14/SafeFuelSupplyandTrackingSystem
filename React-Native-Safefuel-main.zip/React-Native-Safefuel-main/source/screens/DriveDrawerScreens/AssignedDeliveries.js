import { Alert, RefreshControl, ScrollView, StatusBar, StyleSheet, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import { api_url, Poppins_Regular, theme_clr_10_transparent_0, theme_clr_dark, theme_clr_white } from '../../../style_sheet/styles';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import LinearGradient from 'react-native-linear-gradient';
import AppHeader from '../../My_components/Header/AppHeader';
import HistoryCard from '../../My_components/Cards/HistoryCard';
import ReceiptModal from '../../My_components/Modals/ReceiptModal';
import { useSelector } from 'react-redux';
import AssignedDeliveryCard from '../../My_components/Cards/AssignedDeliveryCard';
import DefaultLoading from '../../My_components/Loading/DefaultLoading';

const AssignedDeliveries = () => {

  const navigation = useNavigation();

  const userdata = useSelector(state => state.userdatais.userdata);


  const [refreshing, setRefreshing] = useState(false);
  const [assigneddeliveries, setAssigneddeliveries] = useState([]);
  const [loading, setLoading] = useState(false)

  const fetch_assigned_deliveries = async () => {
    try {
      const response = await fetch(`${api_url}/get_assigned_deliveries`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ driverId: userdata.id }),
      });

      if (!response.ok) {
        throw new Error(`Server timed out`);
      }

      let data = await response.json();
      setAssigneddeliveries(data);

    } catch { setRefreshing(false) }
    finally {
      setRefreshing(false)
    }
  }

  const handleStartJourney = async (driver_id,owner_id,order_number, schedule_date) => {

    const now = new Date();
    let formattedNow = now.toString();
    // console.log('schedule_date:::', schedule_date);

    console.log('schedule_date:::', now.getMonth() + 1,'/',now.getDate(),'/', now.getFullYear());

    let extractedDate = `${now.getMonth() + 1}/${now.getDate()}/${now.getFullYear()}`
    console.log('extracted date::', extractedDate);

    const date = new Date(schedule_date);
    const newScheduledDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
    console.log('newScheduledDate:::', newScheduledDate);

    // Compare formatted dates
    if (extractedDate !== newScheduledDate) {
      Alert.alert(`Today is not the Scheduled Date! ${extractedDate}  ${newScheduledDate}`);
      console.log(`Today is not the Scheduled Date! ${extractedDate}  ${newScheduledDate}`);
      return;
    }
    // Alert.alert(`Today is not the Scheduled Date! ${extractedDate}  ${newScheduledDate}`);

    // console.log('Start Journey Pressed:', order_number, 'Time:', formattedNow);
    try {
      setLoading(true)
      const response = await fetch(`${api_url}/start_journey`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({driverId:driver_id,ownerId:owner_id, orderNumber: order_number, journey_start_time: formattedNow }),
      });

      const data = await response.json();
      await fetch_assigned_deliveries()

      navigation.navigate('Home', { refresh_page: Math.floor(10000 + Math.random() * 90000) })
      console.log('Start Journey Response:', data);

    } catch (error) {
      setLoading(false)
      console.error('Error starting journey:', error);
    } finally {
      setLoading(false)
    }

  }

  useFocusEffect(
    React.useCallback(() => {
      StatusBar.setBackgroundColor(theme_clr_white);
      StatusBar.setTranslucent(false);
      StatusBar.setBarStyle('dark-content');
    }, [])
  );

  useEffect(() => {

    setTimeout(() => {
      fetch_assigned_deliveries()
    }, 100);

  }, [])


  return (
    <LinearGradient
      colors={[theme_clr_white, theme_clr_white, theme_clr_10_transparent_0]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.9, y: 0.9 }}
      style={{ height: '100%' }}
    >
      <AppHeader heading={'Assigned Deliveries'} />
      <DefaultLoading visible={loading} />

      <ScrollView contentContainerStyle={{ paddingHorizontal: 10, paddingTop: 10, paddingBottom: 60 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => {
            fetch_assigned_deliveries();
            setRefreshing(true)
          }} />
        }
      >
        {Array.isArray(assigneddeliveries) && assigneddeliveries.map((item, index) => (
          <AssignedDeliveryCard key={index} data={item} on_press={() => handleStartJourney(item.driver_id,item.owner_id,item.order_number, item.schedule_date_time)} />
        ))

        }

        {assigneddeliveries.length === 0 && (
          <Text style={{ fontSize: 20, fontFamily: Poppins_Regular, color: theme_clr_dark, paddingTop: 50, textAlign: 'center' }}>
            No Deliveries Available!
          </Text>
        )}
      </ScrollView>


    </LinearGradient>
  );
};

export default AssignedDeliveries;
