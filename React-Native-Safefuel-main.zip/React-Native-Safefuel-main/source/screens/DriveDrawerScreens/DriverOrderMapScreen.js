import React, { useEffect, useState, useRef, useCallback } from 'react';
import { StyleSheet, View, Text, Image, StatusBar, TouchableOpacity, Alert, Platform, ScrollView } from 'react-native';
import MapView, { Marker, Polyline, Circle } from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import { EnableLocationPopup, requestLocationPermission } from '../../../HelperFunctions/Permissions_File/Permissions';
import { api_url, height, Montserrat_Bold, Montserrat_Regular, Poppins_Bold, theme_clr_1, theme_clr_10, theme_clr_10_transparent_0_max, theme_clr_3, theme_clr_5, theme_clr_5_medium, theme_clr_6, theme_clr_7, theme_clr_8, theme_clr_8_dark, theme_clr_dark, theme_clr_dull_white, theme_clr_grey_1, theme_clr_white, width } from '../../../style_sheet/styles';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { calculateDistance } from '../../../HelperFunctions/Functions';
import IconComponent from '../../My_components/Icon_Component/IconComponent';
import AppButton from '../../My_components/Buttons/AppButton';

const DriverOrderMapScreen = ({ route }) => {
    const navigation = useNavigation();
    const { routeData } = route.params || {};

    console.log(routeData);


    const [checkinside, setCheckinside] = useState('outside');
    const [location, setLocation] = useState(null);
    const [region, setRegion] = useState(null);
    const [latitudeDelta, setLatitudeDelta] = useState(0.01);
    const [longitudeDelta, setLongitudeDelta] = useState(0.01);
    const [hasLocationPermission, setHasLocationPermission] = useState(false);
    const [loading, setLoading] = useState(true);
    const [deviatemenu, setDeviatemenu] = useState(false);
    const [deviationlist, setDeviationlist] = useState([
        { eng: 'Road Block', urdu: 'سڑک بلاک' },
        { eng: 'Traffic Jam', urdu: 'ٹریفک جام' },
        { eng: 'Road Construction', urdu: 'سڑک کی تعمیر' },
        { eng: 'Construction Work', urdu: 'تعمیراتی کام' },
        { eng: 'Traffic Accident', urdu: 'ٹریفک حادثہ' },
        { eng: 'Landslide', urdu: 'زمین کھسکنا' },
        { eng: 'Road Damage', urdu: 'سڑک کو نقصان' },
        { eng: 'Other Reason ', urdu: 'کچھ اور وجہ' },

    ]);

    const mapRef = useRef(null);
    const markerRef = useRef(null);
    const inRangeTriggerRef = useRef(false);
    const [deviationtrigger, setDeviationtrigger] = useState('')


    const handleDeliverOrder = async (order_has_been) => {
        if (!location || !routeData) return;

        try {
            const total_travel_distance = calculateDistance(
                routeData.start_latitude,
                routeData.start_longitude,
                location.latitude,
                location.longitude
            );
            const now = new Date();
            const formattedDateNow = now.toLocaleString();

            const response = await fetch(`${api_url}/deliver_cancel_order`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    orderIs: order_has_been,
                    driverId: routeData.driver_id,
                    ownerId: routeData.owner_id,
                    orderNumber: routeData.order_number,
                    journeyEnded: formattedDateNow,
                    totalDistance: total_travel_distance
                }),
            });

            const data = await response.json();
            setCheckinside(data.message);
            inRangeTriggerRef.current = true;

            Alert.alert(
                'Message',
                `Order has been ${order_has_been} ${order_has_been === 'Delivered' ? 'Successfully' : ''}`
            );
            navigation.navigate('Home', {
                refresh_page: Math.floor(10000 + Math.random() * 90000)
            });
        } catch (error) {
            console.error('Delivery Error:', error);
            Alert.alert('Error', 'Failed to update order status');
        }
    };

    const handleRouteDeviation = async (reason = 'checking_if_deviated') => {
        setDeviationtrigger(true)
        setDeviatemenu(false);
        console.log('reason', reason);

        try {
            const response = await fetch(`${api_url}/update_deviation`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    driverId: routeData.driver_id,
                    ownerId: routeData.owner_id,
                    orderNumber: routeData.order_number,
                    deviation_reason: reason
                }),
            });

            const data = await response.json();
            console.log('data', data.message);
            setDeviationtrigger(data.message);
            if (reason != 'checking_if_deviated') {
                Alert.alert(`Message sent successfully`);
            }

        } catch (error) {
            console.error('GeoFencing Error:', error);
        }

    }

    const updateGeoFencingData = async () => {
        if (inRangeTriggerRef.current || !routeData) return;
        inRangeTriggerRef.current = true;

        try {
            const response = await fetch(`${api_url}/update_geofence_data`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    driverId: routeData.driver_id,
                    ownerId: routeData.owner_id,
                    orderNumber: routeData.order_number
                }),
            });

            const data = await response.json();
            setCheckinside(data.message);
        } catch (error) {
            console.error('GeoFencing Error:', error);
        }
    };

    const getLocation = useCallback(async () => {
        try {
            await EnableLocationPopup();
            const hasPermission = await requestLocationPermission();
            setHasLocationPermission(hasPermission);

            if (!hasPermission) {
                setLoading(false);
                return;
            }

            Geolocation.getCurrentPosition(
                (position) => {
                    const newLocation = {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                    };

                    setLocation(newLocation);

                    if (!region) {
                        const newRegion = {
                            ...newLocation,
                            latitudeDelta,
                            longitudeDelta,
                        };
                        setRegion(newRegion);
                        setTimeout(() => {
                            mapRef.current?.animateToRegion(newRegion, 1000);
                        }, 500);
                    }

                    markerRef.current?.animateMarkerToCoordinate?.(newLocation, 2000);
                    setLoading(false);
                },
                (error) => {
                    console.error('Location Error:', error);
                    // Don't set error state, just keep previous location
                    setLoading(false);
                },
                {
                    enableHighAccuracy: true,
                    timeout: 15000,
                    maximumAge: 0,
                }
            );
        } catch (error) {
            console.error('Location Setup Error:', error);
            setLoading(false);
        }
    }, [region, latitudeDelta, longitudeDelta]);

    useEffect(() => {
        if (location && routeData?.end_latitude) {
            const distance = calculateDistance(
                location.latitude,
                location.longitude,
                routeData.end_latitude,
                routeData.end_longitude
            );

            if (distance <= 200) {
                updateGeoFencingData();
            }
        }
    }, [location]);

    useEffect(() => {
        let intervalId;

        const init = async () => {
            await getLocation();
            intervalId = setInterval(getLocation, 5000);
        };

        init();

        return () => {
            if (intervalId) clearInterval(intervalId);
        };
    }, [getLocation]);

    useFocusEffect(
        useCallback(() => {
            StatusBar.setBackgroundColor(theme_clr_white);
            StatusBar.setTranslucent(false);
            StatusBar.setBarStyle('dark-content');
        }, [])
    );

    useEffect(() => {
        inRangeTriggerRef.current = false;
        handleRouteDeviation()
    }, [route.params?.key]);

    if (!routeData || !routeData.start_latitude || !routeData.end_latitude) {
        return (
            <View style={styles.container}>
                <Text style={styles.noRouteText}>No valid route data available</Text>
            </View>
        );
    }

    if (loading && !location) {
        return (
            <View style={[styles.container, { backgroundColor: theme_clr_10_transparent_0_max }]}>
                <Text style={{ fontSize: 18, fontFamily: Poppins_Bold, color: theme_clr_dark }}>Loading map data...</Text>
            </View>
        );
    }

    const parseWaypoints = () => {
        try {
            return Array.isArray(routeData.waypoints)
                ? routeData.waypoints
                : JSON.parse(routeData.waypoints || '[]');
        } catch {
            return [];
        }
    };

    const waypoints = parseWaypoints();
    const allCoordinates = [
        { latitude: routeData.start_latitude, longitude: routeData.start_longitude },
        ...waypoints,
        { latitude: routeData.end_latitude, longitude: routeData.end_longitude }
    ].filter(point => point.latitude && point.longitude);

    const handleRegionChange = (newRegion) => {
        setLatitudeDelta(newRegion.latitudeDelta);
        setLongitudeDelta(newRegion.longitudeDelta);
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerContainer}>
                <TouchableOpacity
                    onPress={() => { navigation.goBack(); setDeviatemenu(false) }}
                    style={styles.back_btn}
                >
                    <IconComponent
                        name={'MaterialIcons'}
                        icon={'arrow-back'}
                        size={18}
                        color={theme_clr_white}
                    />
                    <Text style={styles.backText}>back</Text>
                </TouchableOpacity>

                {!inRangeTriggerRef.current && (
                    <View style={{ gap: 5 }}>
                        <AppButton
                            on_press={() => handleDeliverOrder('Canceled')}
                            text={'Cancel Order'}
                            fsize={12}
                            fstyle={'bold'}
                            text_color={theme_clr_white}
                            border={100}
                            btn_height={10}
                            background_color={theme_clr_5_medium}
                        />

                        {deviationtrigger == 'not deviated' && (
                            <AppButton
                                on_press={() => setDeviatemenu(!deviatemenu)}
                                text={`Deviate Route`}
                                fsize={12}
                                // fstyle={'bold'}
                                text_color={theme_clr_white}
                                borderColor={theme_clr_dark}
                                border={100}
                                btn_height={10}
                                background_color={theme_clr_1}
                            />
                        )}

                    </View>
                )}


            </View>

            {deviatemenu &&
                <View style={styles.deviate_menu_view}>

                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 10 }}>
                        <Text style={styles.deviation_header_text}>Reason for Deviation</Text>

                        <TouchableOpacity
                            style={{ backgroundColor: theme_clr_dark, borderRadius: 10, padding: 2 }}
                            onPress={() => setDeviatemenu(false)} >
                            <IconComponent name="Ionicons" icon="close" size={24} color="#fff" />
                        </TouchableOpacity>

                    </View>

                    <ScrollView>
                        {deviationlist.map((item, index) => (
                            <TouchableOpacity
                                onPress={() => handleRouteDeviation(item.eng)}
                                key={index}
                                style={[styles.deviation_text_bar_view, { borderBottomWidth: index === deviationlist.length - 1 ? 0 : 1 }]}>
                                <Text style={styles.deviation_menu_text}>{item.eng}</Text>
                                <Text style={styles.deviation_menu_text}>{item.urdu}</Text>
                            </TouchableOpacity>
                        ))}

                    </ScrollView>

                </View>

            }
            {inRangeTriggerRef.current && (
                <View style={styles.deliver_btn_view}>
                    <AppButton
                        on_press={() => handleDeliverOrder('Delivered')}
                        text={'Deliver Order'}
                        fsize={15}
                        fstyle={'bold'}
                        text_color={theme_clr_white}
                        borderColor={theme_clr_dark}
                        border={10}
                        btn_height={13}
                        background_color={theme_clr_7}
                    />
                </View>
            )}


            <MapView
                ref={mapRef}
                style={styles.map}
                initialRegion={region}
                onRegionChangeComplete={handleRegionChange}
                // showsUserLocation={true}
                followsUserLocation={true}
            >
                {location && (
                    <Marker
                        ref={markerRef}
                        coordinate={location}
                        title="You"
                    >
                        <Image
                            source={require('../../Assets/images/truck.png')}
                            style={styles.truckIcon}
                        />
                    </Marker>
                )}

                <Marker
                    coordinate={{
                        latitude: routeData.start_latitude,
                        longitude: routeData.start_longitude
                    }}
                    title="Start Point"
                >
                    <Image
                        source={require('../../Assets/images/start.png')}
                        style={styles.startIcon}
                    />
                </Marker>

                <Marker
                    coordinate={{
                        latitude: routeData.end_latitude,
                        longitude: routeData.end_longitude
                    }}
                    title="Destination"
                >
                    <Image
                        source={require('../../Assets/images/fueldrop.png')}
                        style={styles.endIcon}
                    />
                </Marker>

                <Circle
                    center={{
                        latitude: routeData.end_latitude,
                        longitude: routeData.end_longitude
                    }}
                    radius={200}
                    strokeWidth={2}
                    strokeColor="lightgreen"
                    fillColor="rgba(0, 255, 0, 0.2)"
                />

                {allCoordinates.length > 1 && (
                    <Polyline
                        coordinates={allCoordinates}
                        strokeColor="#0000FF"
                        strokeWidth={3}
                    />
                )}
            </MapView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    map: {
        ...StyleSheet.absoluteFillObject,
    },
    noRouteText: {
        textAlign: 'center',
        padding: 20,
        color: 'gray',
    },
    headerContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '83%',
        position: 'absolute',
        top: 10,
        left: '15%',
        zIndex: 1,
    },
    back_btn: {
        flexDirection: 'row',
        backgroundColor: theme_clr_dark,
        borderRadius: 100,
        paddingVertical: 8,
        paddingLeft: 10,
        paddingRight: 20,
        alignSelf: 'flex-start',
        alignItems: 'center',
        gap: 5
    },
    backText: {
        fontSize: 10,
        color: theme_clr_white,
        fontFamily: Montserrat_Bold
    },
    deliver_btn_view: {
        position: 'absolute',
        alignSelf: 'center',
        width: 300,
        bottom: '10%',
        zIndex: 1,
    },
    deviate_menu_view: {
        position: 'absolute',
        alignSelf: 'center',
        padding: 5,
        overflow: 'hidden',
        backgroundColor: theme_clr_white,
        borderWidth: 1,
        borderRadius: 15,
        width: width / 1.1,
        height: 300,
        top: 100,
        zIndex: 1,
    },

    deviation_header_text: {
        fontSize: 15,
        fontFamily: Montserrat_Bold,
        color: theme_clr_white,
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: 10,
        backgroundColor: theme_clr_dark,
        textTransform: 'uppercase'
    },

    deviation_text_bar_view: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 12,
        borderColor: theme_clr_grey_1,
    },
    deviation_menu_text: {
        fontSize: 13,
        fontFamily: Montserrat_Regular,
        borderWidth: 1,
        borderColor: theme_clr_dark,
        paddingVertical: 5,
        paddingHorizontal: 15,
        borderRadius: 10
    },
    truckIcon: {
        top: 15,
        width: 30,
        height: 20
    },
    startIcon: {
        width: 35,
        height: 40
    },
    endIcon: {
        width: 30,
        height: 30
    },
});

export default DriverOrderMapScreen;