import { Alert, Image, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { useEffect, useState } from 'react'
import LinearGradient from 'react-native-linear-gradient'
import { api_url, height, Poppins_Bold, Poppins_Regular, theme_clr_10, theme_clr_10_transparent, theme_clr_11, theme_clr_11_transparent, theme_clr_dull_white, theme_clr_dull_white_transparent, theme_clr_light_grey, theme_clr_light_grey_transparent, theme_clr_white, width } from '../../../style_sheet/styles'
import { useNavigation } from '@react-navigation/native'
import Textinput from '../../My_components/TextInputs/Textinput'
import AppButton from '../../My_components/Buttons/AppButton'
import DropdownType1 from '../../My_components/Dropdowns/DropdownType1'
import { firebase_user_SignOut, getAndStoreFcmToken } from '../../../FireBase/FireBaseFunctions'
import { getAuth } from '@react-native-firebase/auth'
import { get_user_credentials, set_user_credentials } from '../../../HelperFunctions/Async_storage/User_Credentials'
import DefaultLoading from '../../My_components/Loading/DefaultLoading'

const SignUp = () => {
  const navigation = useNavigation()

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [phone, setPhone] = useState('')
  const [role, setRole] = useState('Owner')
  const [tankernumber, setTankerNumber] = useState('')
  const [avgfuel, setAvgfuel] = useState('')
  const [fuelcapacity, setFuelcapacity] = useState('')

  const [loading, setLoading] = useState(false)


  useEffect(() => {
    if (role == 'Owner') {
      setTankerNumber('')
      setAvgfuel('')
      setFuelcapacity('')
    }
  }, [role])

  const user_signin_ = async () => {

    try {
      setLoading(true);
      const response = await fetch(`${api_url}/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          u_id: '',
          u_name: name,
          u_email: email,
          u_password: password,
          u_role: role,
          u_phone: phone,
          u_fcm_token: await getAndStoreFcmToken(),
          t_number: tankernumber,
          avg_fuel_consumption: avgfuel,
          fuel_capacity: fuelcapacity,

        }),
      });

      if (!response.ok) {
        setLoading(false);
        await firebase_user_SignOut();
        throw new Error(`Server timed out`);
      }

      await getAuth().createUserWithEmailAndPassword(email, password);
      setLoading(false);

      await set_user_credentials('0', '0', '0');
      await firebase_user_SignOut();

      if (get_user_credentials.email != '0' && get_user_credentials.password != '0' && get_user_credentials.user_role != '0') {
        // setIsAuthenticated(true);
        navigation.navigate('SignIn');

      }

    } catch (error) {
      setLoading(false);
      console.error("Signup Error:", error);  // Log the exact error
      Alert.alert(`Something went wrong! ${error.message}`); // Show detailed error

      Alert.alert(`Something went wrong !`);
    }
    finally {
      setLoading(false);
    }
  };

  const user_signin = async () => {
    if (name && email && password && phone) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (password.length < 6) {
        Alert.alert('Password length should be at least 6 characters');
        return;
      }

      if (!emailRegex.test(email)) {
        Alert.alert('Invalid Email Address');
        return;
      }

      if (phone.length !== 11) {
        Alert.alert('Invalid Phone Number');
        return;
      }
    } else {
      Alert.alert('Fill all inputs');
      return;
    }


    try {
      console.log('data:::', data);


      const response = await fetch(`${api_url}/email_check_if_exists`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_email: email }),
      });



      const data = await response.json();
      console.log('data:::', data);

      console.log('data:::', data);
      if (!response.ok) {
        console.log('data111:::', data);
        Alert.alert(data.message)
      }

      if (data.message == 'ok') {
        console.log('data2222:::', data);
        setLoading(false);
        // navigation.navigate(
        //   'CodeVerification',{
        //   name:name,
        //   email:email,
        //   password:password,
        // });

        await user_signin_();
      }

    } catch (error) {
      setLoading(false);
    }
    finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient
      colors={[theme_clr_white, theme_clr_white, theme_clr_10]}
      start={{ x: 0, y: 0 }}
      end={{ x: .9, y: .9 }}
      style={{ height: '100%' }}
    >
      <StatusBar barStyle={'dark-content'} backgroundColor={theme_clr_white} />
      <DefaultLoading visible={loading} />

      <ScrollView showsVerticalScrollIndicator={false}>

        <Image source={require('../../Assets/images/logo.png')}
          style={{ height: width / 2, width: width, opacity: .2, top: 130, position: 'absolute' }} />


        <Text style={[styles.page_text, { marginTop: height / 10, marginBottom: -height / 15 }]}>SIGN UP</Text>
        {/* <Text style={styles.page_text}>SIGN{'\n'}UP</Text> */}

        <View style={styles.input_view}>

          <View style={{ gap: 5, marginBottom: 30 }}>
            <Textinput
              text={'Name'}
              place_holder={'Enter your name'}
              set_val={setName}
              val={name}
            />

            <Textinput
              text={'Email'}
              place_holder={'Enter your email'}
              set_val={setEmail}
              val={email}
            />

            <Textinput
              text={'Password'}
              place_holder={'Enter your password'}
              set_val={setPassword}
              val={password}
              type={'password'}
            />

            <Textinput
              text={'Phone Number'}
              place_holder={'Enter your phone no.'}
              max_length={11}
              set_val={setPhone}
              input_mode={'numeric'}
              val={phone}
            />

            <DropdownType1
              title={`Select Role`}
              set_seleted_option={setRole}
              seleted_option={role}
              data_list={[
                { data: 'Owner' },
                { data: 'Driver' },
              ]}
              dropdown_height={100}
            />

            {role == 'Driver' &&
              <>    <Textinput
                text={'Tanker Number'}
                place_holder={'Enter tanker no.'}
                set_val={setTankerNumber}
                val={tankernumber}
              />

                <Textinput
                  text={'Avg. Fuel Consumption( per k/m )'}
                  place_holder={'Enter fuel consumption'}
                  set_val={setAvgfuel}
                  val={avgfuel}
                  input_mode={'numeric'}

                />
                <Textinput
                  text={'Tanker Fuel Capacity'}
                  place_holder={'Enter fuel capacity'}
                  set_val={setFuelcapacity}
                  val={fuelcapacity}
                  input_mode={'numeric'}
                />
              </>}


          </View>

          <AppButton
            on_press={() => user_signin()}
            text={'Sign Up'}
            fsize={15}
            fstyle={'regular'}
            text_color={'#fff'}
            border={8}
            btn_height={14}
            background_color={theme_clr_10}
          />


        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', alignSelf: 'center', marginVertical: 10 }}>
          <Text style={[styles.text, { fontSize: 14 }]}>Already have an account?</Text>
          <TouchableOpacity
            onPress={() => navigation.navigate('SignIn')}
          >
            <Text style={{ color: theme_clr_11, textDecorationLine: 'underline', fontFamily: Poppins_Bold, paddingVertical: 10 }}> Sign in</Text>
          </TouchableOpacity>
        </View>



      </ScrollView>
    </LinearGradient>
  )
}

export default SignUp

const styles = StyleSheet.create({
  page_text: {
    color: theme_clr_10_transparent,
    // fontSize: width / 3,
    fontSize: width / 5,
    margin: 10,
    marginTop: '10%',
    lineHeight: width / 3,
    fontFamily: Poppins_Bold
  },
  input_view: {
    borderWidth: 2,
    borderColor: theme_clr_10_transparent,
    backgroundColor: theme_clr_dull_white_transparent,
    marginHorizontal: 10,
    paddingVertical: 20,
    marginTop: '10%',
    padding: 10,
    borderRadius: 15
  },
  text: {
    color: theme_clr_white,
    fontSize: 12,
    textAlign: 'center',
    fontFamily: Poppins_Regular
  },
})