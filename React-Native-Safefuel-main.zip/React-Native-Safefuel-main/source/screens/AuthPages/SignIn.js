import { Alert, Image, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { useEffect, useState } from 'react'
import LinearGradient from 'react-native-linear-gradient'
import { api_url, height, Poppins_Bold, Poppins_Regular, theme_clr_10, theme_clr_10_transparent, theme_clr_11, theme_clr_11_transparent, theme_clr_dull_white, theme_clr_dull_white_transparent, theme_clr_light_grey, theme_clr_light_grey_transparent, theme_clr_white, width } from '../../../style_sheet/styles'
import { useNavigation } from '@react-navigation/native'
import Textinput from '../../My_components/TextInputs/Textinput'
import AppButton from '../../My_components/Buttons/AppButton'
import { setNavnameis } from '../../../redux/slice/NavigationStateSlice'
import { useDispatch } from 'react-redux'
import { getAuth, GoogleAuthProvider } from '@react-native-firebase/auth'
import { firebase_user_signedin_check, firebase_user_SignOut, getAndStoreFcmToken } from '../../../FireBase/FireBaseFunctions'
import { get_user_credentials, set_user_credentials } from '../../../HelperFunctions/Async_storage/User_Credentials'
import { GOOGLE_WEB_CLIENT_ID } from '../../../configurations_files/Config'
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import DefaultLoading from '../../My_components/Loading/DefaultLoading'
import SignInWithGoogleModal from '../../My_components/Modals/SignInWithGoogleModal'

const SignIn = () => {
  const dispatch = useDispatch();

  const navigation = useNavigation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const [phone, setPhone] = useState('')
  const [role, setRole] = useState('Owner')
  const [tankernumber, setTankerNumber] = useState('')
  const [avgfuel, setAvgfuel] = useState('')
  const [fuelcapacity, setFuelcapacity] = useState('')
  const [signinmodal, setSigninmodal] = useState(false)


  const [usr_id, setUsr_id] = useState('')
  const [usr_name, setUsr_name] = useState('')
  const [usr_email, setUsr_email] = useState('')


  const user_login = async () => {

    if (email.trim() == '' || password.trim() == '') {
      Alert.alert(`Please fill all inputs`)
      return
    }

    if (!password || password.trim().length < 6) {
      Alert.alert(`Password must be at least 6 characters`)
      return
    }

    try {
      setLoading(true);

      const userCredential = await getAuth().signInWithEmailAndPassword(email, password);
      // console.log('User signed in successfully!');
      const userId = userCredential.user.uid;

      const response = await fetch(`${api_url}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          user_email: email,
          user_fcm_token: await getAndStoreFcmToken()
        }),
      });
      
      
      const data = await response.json(); 

      setLoading(false);
      if (!response.ok) {
        await firebase_user_SignOut();
        Alert.alert(`Error`,data.message);
        throw new Error(`Server timed out`);
      }
      setLoading(false);


      if (data) {
        console.log("Response Role:", data.u_role); // Now it should log the correct role
      }


      await set_user_credentials(email, password, data.u_role);

      // if (firebase_user_signedin_check() && get_user_credentials.email != '0' && get_user_credentials.password != '0' && get_user_credentials.user_role != '0') {
      // navigation.navigate('AppDrawer');
      // setIsAuthenticated(true);
      if (data.u_role == 'Owner') {
        dispatch(setNavnameis('ownerscreens'));
      }
      else if (data.u_role == 'Driver') {
        dispatch(setNavnameis('driverscreens'));
      }
      // }
      // navigation.navigate('AppDrawer');
      //   console.log(getAndStoreFcmToken(userId));


    } catch (error) {
      setLoading(false);
      if (error.code === 'auth/invalid-credential') {
        Alert.alert('Invalid user email or password');
      }

      return null;
    }
  }

  // useEffect(() => {
  //   setEmail(email.toLowerCase().trim());
  //   setPassword(password.trim())
  // }, [email, password])

  ////////////////////////////////////////////// testing
  useEffect(() => {
    GoogleSignin.configure({
      webClientId: GOOGLE_WEB_CLIENT_ID,  // Correct web client ID
      offlineAccess: true,  // If you need refresh tokens
      scopes: ['profile', 'email']  // Necessary scopes
    });
  }, []);



  const check_and_signin_with_google = async () => {
    try {
      setLoading(true)
      await GoogleSignin.signOut();

      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();
      console.log('User Info:', JSON.stringify(userInfo, null, 2));

      const { idToken } = await GoogleSignin.getTokens();
      const googleCredentials = GoogleAuthProvider.credential(idToken);

      await getAuth().signInWithCredential(googleCredentials);
      console.log('Signed in with Google successfully', userInfo);

      setUsr_id(userInfo.data.user.id)
      setUsr_name(userInfo.data.user.name)
      setUsr_email(userInfo.data.user.email)

      const response1 = await fetch(`${api_url}/check_google_user`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_email: userInfo.data.user.email,
          user_fcm_token: await getAndStoreFcmToken()
        }),
      });

      const data = await response1.json();

      // console.log('User Role:', data.data[0].u_role);

      // console.log('in data11', data.data[0]);
      // console.log('in data1122', data.message);
      console.log('in data1122', data);

      if (data.message == "ok data" && data.data.length > 0) {

        await set_user_credentials(data.data[0].u_email, '0', data.data[0].u_role);

        console.log('in data22');
        let user_cred = await get_user_credentials();

        console.log('in data', user_cred.user_role);

        if (firebase_user_signedin_check() && user_cred.email != '0' && user_cred.user_role != '0') {
          let data = user_cred.user_role
          if (data == 'Owner') {
            dispatch(setNavnameis('ownerscreens'));
          }
          else {
            dispatch(setNavnameis('driverscreens'));
          }
        }
      }
      else if (data.message == 'no data') {
        setSigninmodal(true)
      }
    } catch (error) {
      console.log('Google Sign-In Error:', error);
      Alert.alert('Google Sign-In failed!');
    }finally{
      setLoading(false)
    }
  }

  ///////////////////////////////////////////////////////////
  const signInWithGoogle = async () => {
    if (phone.trim() == '') {
      Alert.alert('Please Enter your Phone Number !')
      return
    }
    if (phone.length != 11) {
      Alert.alert('Invalid Phone Number !')
      return
    }
    if (role == 'Driver' && tankernumber.trim() == '' && avgfuel.trim()=='') {
      Alert.alert('Enter complete Truck Details !')
      return
    }

    try {
      setLoading(true);


      const userData = {
        u_id: usr_id,
        u_name: usr_name,
        u_email: usr_email,
        u_password: '2j"(FK)"!??~/!("S$G*(GOOGLE)3$%VF)57feO£9cKW*"D',
        u_role: role,
        u_phone: phone,
        u_fcm_token: await getAndStoreFcmToken(),
        t_number: tankernumber,
        avg_fuel_consumption: avgfuel,
        fuel_capacity: fuelcapacity,
      };

      console.log('userData::::', userData);

      const response = await fetch(`${api_url}/signin_with_google`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });

      if (!response.ok) {
        setLoading(false);
        await getAuth().signOut();
        // console.log(`signed out`);
        throw new Error(`Server timed out`);
      }
      setLoading(false);
      await set_user_credentials(userData.u_email, userData.u_password, userData.u_role);

      if (firebase_user_signedin_check() && get_user_credentials.email != '0' && get_user_credentials.password != '0' && get_user_credentials.user_role != '0') {
        //   navigation.navigate('AppDrawer');
        // setIsAuthenticated(true);
        if (userData.u_role == 'Owner') {
          dispatch(setNavnameis('ownerscreens'));
        }
        else {
          dispatch(setNavnameis('driverscreens'));
        }
      }

      console.log('User data saved successfully in the database');
    } catch (error) {
      setLoading(false);
      console.log('Error occurred during Google Sign-In:', error);
    }
    finally {
      setLoading(false);
    }
  };


  return (
    <LinearGradient
      colors={[theme_clr_white, theme_clr_white, theme_clr_10]}
      start={{ x: 0, y: 0 }}
      end={{ x: .9, y: .9 }}
      style={{ height: '100%' }}
    >
      <StatusBar barStyle={'dark-content'} backgroundColor={theme_clr_white} />
      <DefaultLoading visible={loading} />
      <ScrollView showsVerticalScrollIndicator={false}>

        <Image source={require('../../Assets/images/logo.png')}
          style={{ height: width / 2, width: width, opacity: .2, top: 130, position: 'absolute' }} />



        <Text style={[styles.page_text,{marginTop:height/7}]}>SIGN IN</Text>
        {/* <Text style={styles.page_text}>SIGN{'\n'}IN</Text> */}

        <View style={styles.input_view}>

          <View style={{ gap: 5, marginBottom: 30 }}>
            <Textinput
              text={'Email'}
              place_holder={'Enter your email'}
              set_val={setEmail}
              val={email}
            />

            <Textinput
              text={'Password'}
              place_holder={'Enter your password'}
              set_val={setPassword}
              val={password}
              type={'password'}
            />

          </View>

          <View style={{ gap: 10 }}>
            <AppButton
              on_press={() => user_login()}
              text={'Sign In'}
              fsize={15}
              fstyle={'regular'}
              text_color={'#fff'}
              border={8}
              btn_height={14}
              background_color={theme_clr_10}
            />

            <AppButton
              on_press={() => check_and_signin_with_google()}
              text={'Sign In With Google'}
              fsize={15}
              fstyle={'regular'}
              text_color={'#fff'}
              border={8}
              btn_height={14}
              background_color={theme_clr_10}
            />

          </View>

        </View>

{/* 

        <Text>{phone}</Text>
        <Text>{tankernumber}</Text>
        <Text>{avgfuel}</Text>
        <Text>{role}</Text>
 */}


        <View style={{ flexDirection: 'row', alignItems: 'center', alignSelf: 'center', marginVertical: 10 }}>
          <Text style={[styles.text, { fontSize: 14 }]}>Don’t have an account?</Text>
          <TouchableOpacity
            onPress={() => navigation.navigate('SignUp')}
          >
            <Text style={{ color: theme_clr_11, textDecorationLine: 'underline', fontFamily: Poppins_Bold, paddingVertical: 10 }}> Sign up</Text>
          </TouchableOpacity>
        </View>


        {signinmodal &&
          <SignInWithGoogleModal setPhone={setPhone}
            setRole={setRole}
            visible={signinmodal}
            setvisible={setSigninmodal}
            on_press={() => signInWithGoogle()}
            setTankerNumber={setTankerNumber}
            setAvgfuel={setAvgfuel}
            setFuelcapacity={setFuelcapacity}
            />

        }

      </ScrollView>
    </LinearGradient>
  )
}

export default SignIn

const styles = StyleSheet.create({
  page_text: {
    color: theme_clr_10_transparent,
    // fontSize: width / 3,
    fontSize: width / 5,
    margin: 10,
    marginTop: '10%',
    lineHeight: width / 3,
    fontFamily: Poppins_Bold
  },
  input_view: {
    borderWidth: 2,
    borderColor: theme_clr_10_transparent,
    backgroundColor: theme_clr_dull_white_transparent,
    marginHorizontal: 10,
    paddingVertical: 20,
    marginTop: '10%',
    padding: 10,
    borderRadius: 15
  },
  text: {
    color: theme_clr_white,
    fontSize: 12,
    textAlign: 'center',
    fontFamily: Poppins_Regular
  },
})