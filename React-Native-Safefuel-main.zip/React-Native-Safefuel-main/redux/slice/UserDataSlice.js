import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  userdata: {},
};

const UserDataSlice = createSlice({
  name: 'userdatais',
  initialState,
  reducers: {
    setUserData: (state, action) => {
      state.userdata = action.payload; 
    },
  },
});

export const { setUserData} = UserDataSlice.actions;
export default UserDataSlice.reducer;
