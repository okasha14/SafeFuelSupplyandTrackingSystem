import { configureStore } from '@reduxjs/toolkit';
 import navReducer from '../slice/NavigationStateSlice'
 import userdataReducer from '../slice/UserDataSlice'
 
export const store = configureStore({
    reducer: {
        navnameis: navReducer,
        userdatais: userdataReducer,
     },
});
