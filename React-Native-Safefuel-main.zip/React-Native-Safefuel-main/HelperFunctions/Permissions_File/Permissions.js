import { PermissionsAndroid, Platform, Linking, Alert } from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import { checkNotifications, openSettings, requestNotifications } from 'react-native-permissions';


import { promptForEnableLocationIfNeeded } from 'react-native-android-location-enabler';



export const requestLocationPermission = async () => {
  try {
    if (Platform.OS === 'android') {
      // Check if permissions are already granted
      const fineLocationGranted = await PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
      );

      const coarseLocationGranted = await PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION
      );

      if (fineLocationGranted && coarseLocationGranted) {
        return true; // Permissions already granted
      }

      // Request both permissions
      const granted = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
      ]);

      return (
        granted['android.permission.ACCESS_FINE_LOCATION'] === PermissionsAndroid.RESULTS.GRANTED &&
        granted['android.permission.ACCESS_COARSE_LOCATION'] === PermissionsAndroid.RESULTS.GRANTED
      );
    }

    if (Platform.OS === 'ios') {
      const status = await Geolocation.requestAuthorization('whenInUse');
      return status === 'granted';
    }
  } catch (error) {
    console.error('Permission error:', error);
    return false;
  }
};


export const EnableLocationPopup = async () => {
  if (Platform.OS === 'android') {
    try {
      const enableResult = await promptForEnableLocationIfNeeded();
      console.log('enableResult', enableResult);
      // The user has accepted to enable the location services
      // data can be :
      //  - "already-enabled" if the location services has been already enabled
      //  - "enabled" if user has clicked on OK button in the popup
    } catch (error) {
      if (error instanceof Error) {
        console.error(error.message);
        // The user has not accepted to enable the location services or something went wrong during the process
        // "err" : { "code" : "ERR00|ERR01|ERR02|ERR03", "message" : "message"}
        // codes :
        //  - ERR00 : The user has clicked on Cancel button in the popup
        //  - ERR01 : If the Settings change are unavailable
        //  - ERR02 : If the popup has failed to open
        //  - ERR03 : Internal error
      }
    }
  }
}


// export const checkAndPromptNotification = async () => {
//   const { status } = await checkNotifications();

//   if (status !== 'granted') {
//     Alert.alert(
//       'Enable Notifications',
//       'Please enable notifications in settings to receive alerts.',
//       [
//         {
//           text: 'Open Settings',
//           onPress: () => {
//             if (Platform.OS === 'ios') {
//               Linking.openURL('app-settings:');
//             } else {
//               openSettings(); // Android
//             }
//           },
//         },
//         {
//           text: 'Cancel',
//           style: 'cancel',
//         },
//       ],
//     );
//   }
// };



export const checkAndPromptNotification = async () => {
  // Android 13+ requires runtime permission
  if (Platform.OS === 'android' && Platform.Version >= 33) {
    const { status } = await checkNotifications();

    if (status !== 'granted') {
      const { status: newStatus } = await requestNotifications([
        'alert',
        'sound',
        'badge',
      ]);

      if (newStatus !== 'granted') {
        Alert.alert(
          'Enable Notifications',
          'Please enable notifications in settings to receive alerts.',
          [
            {
              text: 'Open Settings',
              onPress: () => openSettings(),
            },
            { text: 'Cancel', style: 'cancel' },
          ]
        );
      }
    }
  } else {
    // Android < 13 and iOS — just check status and show message
    const { status } = await checkNotifications();

    if (status !== 'granted') {
      Alert.alert(
        'Enable Notifications',
        'Please enable notifications in settings to receive alerts.',
        [
          {
            text: 'Open Settings',
            onPress: () => openSettings(),
          },
          { text: 'Cancel', style: 'cancel' },
        ]
      );
    }
  }
};
