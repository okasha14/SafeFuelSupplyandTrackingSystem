// services/api.js

import { api_url } from "../../style_sheet/styles"

export const getUserData = async (user_email) => {
    try {
        const response = await fetch(`${api_url}/get_user_data_with_email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_email:user_email }),
        });

        if (!response.ok) {
            throw new Error('Failed to fetch user data');
        }

        const data = await response.json();
        console.log('User Data:', data);
        return data;
    } catch (error) {
        console.error('Error fetching user data:', error);
        return null;
    }
};
