import AsyncStorage from '@react-native-async-storage/async-storage';

export const set_user_credentials = async (email, password,user_role) => {
  try {
    const userCredentials = { email, password ,user_role};
    await AsyncStorage.setItem('user_credentials', JSON.stringify(userCredentials));
    // console.log('User credentials saved successfully',email,'     ',password);
  } catch (error) {
    console.error('Error saving user credentials:', error);
  }
};


export const get_user_credentials = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('user_credentials');
      return jsonValue != null ? JSON.parse(jsonValue) : null;
    } catch (error) {
      console.error('Error retrieving user credentials:', error);
    }
  };