import { getApp } from '@react-native-firebase/app';
import { getAuth } from '@react-native-firebase/auth';
import { getMessaging } from '@react-native-firebase/messaging';
import { getFunctions, httpsCallable } from '@react-native-firebase/functions';
import { Alert } from 'react-native';
import messaging from '@react-native-firebase/messaging';
import notifee, { AndroidImportance } from '@notifee/react-native';


// Get Firebase app instance
const app = getApp();

// Function to get the FCM token
export async function getAndStoreFcmToken() {
  try {
    const messaging = getMessaging(app);
    const fcmToken = await messaging.getToken();
    console.log('Attempting to retrieve FCM Token...');
    if (fcmToken) {
      console.log('FCM token retrieved:', fcmToken);
      return fcmToken;
    } else {
      console.log('No FCM token retrieved.');
      return null;
    }
  } catch (error) {
    console.error('Error getting FCM token:', error);
    return null;
  }
}

// Function to send a custom notification
// export async function sendCustomNotification(userId, title, body) {
//   try {
//     const functions = getFunctions(app);
//     const sendNotification = httpsCallable(functions, 'sendNotification');
//     const result = await sendNotification({ userId, title, body });
//     console.log('Notification result:', result.data);
//   } catch (error) {
//     console.error('Error sending notification:', error);
//   }
// }

// // Notification listener
// export const notificationListener = (setData) => {
//   const messaging = getMessaging(app);

//   // Listen for foreground messages
//   const unsubscribeOnMessage = messaging.onMessage(async remoteMessage => {
//     console.log('A new FCM message arrived!', JSON.stringify(remoteMessage));
//     setData(remoteMessage.notification);
//   });

//   // Listen for background notification clicks
//   const unsubscribeOnNotificationOpenedApp = messaging.onNotificationOpenedApp(remoteMessage => {
//     console.log('Notification caused app to open from background state:', remoteMessage.notification);
//     setData(remoteMessage.notification);
//   });

//   // Cleanup listeners
//   return () => {
//     unsubscribeOnMessage();
//     unsubscribeOnNotificationOpenedApp();
//   };
// };

// notificationHandler.js



export async function setupForegroundNotificationListener() {
  // Create a channel for Android
  await notifee.createChannel({
    id: 'default',
    name: 'Default Channel',
    importance: AndroidImportance.HIGH,
  });

  // Listen for foreground FCM messages
  const unsubscribe = getMessaging().onMessage(async remoteMessage => {
    console.log('Foreground message received:', remoteMessage);

    // Optional: Alert if needed
    // Alert.alert(remoteMessage.notification?.title, remoteMessage.notification?.body);

    // Display local notification using Notifee
    await notifee.displayNotification({
      title: remoteMessage.notification?.title || 'Notification',
      body: remoteMessage.notification?.body || 'You have a new message.',
      android: {
        channelId: 'default',
        smallIcon: 'ic_launcher', // Ensure this exists in your Android project
        pressAction: {
          id: 'default',
        },
      },
    });
  });

  return unsubscribe;
}


// Check if user is signed in
export const firebase_user_signedin_check = () => {
  const auth = getAuth(app);
  const user = auth.currentUser;
  return !!user;
};

// Sign out user
export const firebase_user_SignOut = async () => {
  try {
    const auth = getAuth(app);
    await auth.signOut();
  } catch (error) {
    Alert.alert('Error signing out!');
  }
};
